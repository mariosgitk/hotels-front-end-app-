

jQuery(init);
function init($) {

    const URL = "data.json";
    const settings = {
        url: URL,
        success: handleSuccess

    }


    let hotelsSection = document.querySelector("#hotels")
    let propertyType = document.getElementById("stars");
    let location = document.getElementById("location");

    let hotelsData = [];
    let hotelCities = [];
    let hotelEntries = [];
    let roomTypes = [];
    let filtersList = [];
    let filterOptions = [];
    let guestRating = [];
    let starsList = [];
    let cities = [];


    $.ajax(settings);
    function handleSuccess(data) {

        hotelsData = data;
        roomTypes = hotelsData[0].roomtypes;


        const datalist = $("datalist");

        let options = "";
        for (let i = 0; i < hotelsData[1].entries.length; i++) {

            hotelCities[i] = hotelsData[1].entries[i].city;

        }

        hotelCities = Array.from(new Set(hotelCities));

        for (let i = 0; i < hotelCities.length; i++) {

            const hotelOption = `<option value= ${hotelCities[i]}></option>`;

            options += hotelOption;

        }

        $(datalist).html(options);


        let roomOptions = [];

        const roomTypesSection = $("#rooms");


        for (let i = 0; i < roomTypes.length; i++) {

            let roomTypeOption1 = `<option value="" disabled selected>Choose room type</option>`
            let roomTypeOption = `<option value="${roomTypes[i].name}">${roomTypes[i].name}</option>`

            roomOptions.push(roomTypeOption1);
            roomOptions.push(roomTypeOption);
        }

        roomOptions = Array.from(new Set(roomOptions));

        $(roomTypesSection).html(roomOptions);




        hotelEntries = hotelsData[1].entries
        let ratingOption = [];
        hotelEntries.map(function (hotel) {

            const starDisabled = `<option value="" disabled selected>Property type</option>`
            const ratingOptions = `<option value="${hotel.rating}">${hotel.rating} stars</option>`

            ratingOption.push(starDisabled)

            ratingOption.push(ratingOptions)
        })

        ratingOption = Array.from(new Set(ratingOption));

        propertyType.innerHTML = ratingOption;

        hotelEntries.map(function (hotel) {

            cities.push(hotel.city);

        })

        cities = Array.from(new Set(cities));

        let cityOptions = [];
        cities.map(function (city) {
            const template1 = `<option value="" disabled selected>Locations</option>`
            const template = `<option value="${city}">${city} </option>`
            cityOptions.push(template1);
            cityOptions.push(template);
        })
        cityOptions = Array.from(new Set(cityOptions))

        location.innerHTML = cityOptions





    };


    let val = 0;
    let priceRange = document.getElementById('price');
    let priceDisplay = document.getElementById('textInput');

    priceRange.addEventListener("input", function () {

        val = priceRange.value
        priceDisplay.innerHTML = val;
    })



    priceRange.addEventListener("change", function () {
        hotelsSection.innerHTML = '';
        let priceSelected = priceDisplay.innerHTML


        let priceFiltered = hotelEntries.filter(function (hotel) {

            return hotel.price <= priceSelected / 1

        })

        priceFiltered.map(function (hotel) {

            hotelsSection.innerHTML += display(hotel.rating, hotel.thumbnail, hotel.hotelName, hotel.city, hotel.ratings.no, hotel.ratings.text, hotel.price, hotel.filters.length, hotel.filters);
        })

    })

    function display(rating, thumbnail, hotelName, city, ratingsNo, ratingsText, price, filtersLength, filter) {
        let ratingStar = "";
        let filterOptions = "";
        for (let i = 1; i <= rating; i++) {
            ratingStar = ratingStar + `<i class="fas fa-star text-warning"></i>`;

            if (i == rating && i < 5) {
                for (let j = rating; j < 5; j++) {
                    ratingStar = ratingStar + `<i class="fas fa-star text-muted"></i>`;
                }
            }
        }

        for (let i = 0; i < filtersLength; i++) {

            let filterOption = filter[i].name + " , "
            filterOptions += filterOption

        }

        let benefits = filterOptions.substring(0, filterOptions.length - 2);

        const template = `
            <div class="col-md-3" style="margin-top: 6px; padding: 0"">
            <img  class="img-fluid" src="${thumbnail}" alt="${hotelName}" />
            </div>
            <div class="col-md-5" style="margin-top: 4px;   border-style: ridge; background-color: white">
            <h3><b>${hotelName}</b></h3>`
            + ratingStar + ` Hotel <br>
            <i> ${city} , </i> <br>
            <b>${ratingsNo} ${ratingsText}</b><br><br>
            Excellent location <br> <strong>Benefits : &nbsp;</strong> <i>`
            + benefits + `</i>
            </div> 
            <div class="col-md-4" style = "text-align:center; margin-top: 4px; border-style: ridge; background-color: white"><br>
             <i style="color:green">Hotel WebSite</i> <br>
             <h5 style="color:green"><b>$${price}</b><h5><br><br>
             <button id="deal"><h5>View Deal &nbsp;&nbsp; ></h5></button>
             </div>`;

        return template;
    }




    propertyType.addEventListener("change", function () {
        hotelsSection.innerHTML = '';
        hotelEntries = hotelsData[1].entries;
        let result = $("#stars").get(0).value;

        let starRating = hotelEntries.filter(function (hotel) {

            return hotel.rating === result / 1  // to result einai string opote to parsarw se int

        })

        starRating.map(function (hotel) {



            hotelsSection.innerHTML += display(hotel.rating, hotel.thumbnail, hotel.hotelName, hotel.city, hotel.ratings.no, hotel.ratings.text, hotel.price, hotel.filters.length, hotel.filters);

        })
    });







    let guests = document.getElementById("guests");

    guests.addEventListener("change", function () {
        hotelsSection.innerHTML = '';
        hotelEntries = hotelsData[1].entries;
        let result = $("#guests").get(0).value;

        guestRating = hotelEntries.filter(function (hotel) {

            return hotel.ratings.text === result

        })

        guestRating.map(function (hotel) {


            hotelsSection.innerHTML += display(hotel.rating, hotel.thumbnail, hotel.hotelName, hotel.city, hotel.ratings.no, hotel.ratings.text, hotel.price, hotel.filters.length, hotel.filters);
        })

    });


    $("form").submit(function (e) {
        e.preventDefault();
        hotelsSection.innerHTML = '';
        hotelEntries = hotelsData[1].entries;
        let result = $("#hotels_input").get(0).value;
        let filterSection = document.getElementById("filters");


        function optionSelected(hotel) {
            return hotel.city.toUpperCase() === result.toUpperCase();
        }

        var citySelected = hotelEntries.filter(optionSelected);

        citySelected.map(displayHotels);

        if (result !== "") {

            let map = $("#mapIframe");
            const template = `
            <iframe
            width="220"
            height="55"
            frameborder="0" style="border:0;"
            src="${citySelected[0].mapurl}" allowfullscreen>
            </iframe>`

            $(map).html(template);

        }


        function displayHotels(hotel) {

            hotelsSection.innerHTML += display(hotel.rating, hotel.thumbnail, hotel.hotelName, hotel.city, hotel.ratings.no, hotel.ratings.text, hotel.price, hotel.filters.length, hotel.filters);
        }

        var i = 0;
        while (i < citySelected.length) {          // fernw ta filters apo ta hotels pou vriskonte stin epilegmeni polh

            for (let j = 0; j < citySelected[i].filters.length; j++)
                filtersList.push(citySelected[i].filters[j].name);

            i++
        }

        filtersList = Array.from(new Set(filtersList));        // tous vgazw ta diplotypa kai ta emfanizw sti lista

        filtersList.map(displayFilters)

        function displayFilters(filter) {

            let template1 = `<option value=""disabled selected>Sort by benefits</option>`
            let template = `<option value="${filter}">${filter}</option>`

            filterOptions.push(template1)
            filterOptions.push(template)
        }

        filterOptions = Array.from(new Set(filterOptions))
        filterSection.innerHTML = filterOptions

        filterOptions = [];       // adeiazw to html gia na mi ta pros8etei sinexws
        filtersList.length = 0;   // adeiazw kai ti lista me ta filtra ka8e fora gia na mpainoun ta antistoixa tis ka8e anazitisis

        filterSection.addEventListener("change", function () {
            hotelsSection.innerHTML = "";
            let result1 = $("#filters").get(0).value
            

            
            filterSelected = [];

            citySelected.map(function (hotel) {
               

                
                for (let k = 0; k < hotel.filters.length; k++) {

                    console.log(hotel.filters[k].name)
                    if (hotel.filters[k].name === result1) {

                        filterSelected.push(hotel);
                    }
                       
                }

            });

            filterSelected.map(function(hotel){

                hotelsSection.innerHTML += display(hotel.rating, hotel.thumbnail, hotel.hotelName, hotel.city, hotel.ratings.no, hotel.ratings.text, hotel.price, hotel.filters.length, hotel.filters);

            })



        })


    });

    location.addEventListener("change", function () {
        hotelsSection.innerHTML = '';
        hotelEntries = hotelsData[1].entries;
        let result = $("#location").get(0).value

        hotelCities = hotelEntries.filter(function (hotel) {

            return hotel.city.toUpperCase() === result.toUpperCase()

        })

        hotelCities.map(function (hotel) {

            hotelsSection.innerHTML += display(hotel.rating, hotel.thumbnail, hotel.hotelName, hotel.city, hotel.ratings.no, hotel.ratings.text, hotel.price, hotel.filters.length, hotel.filters);

        })
    })




}